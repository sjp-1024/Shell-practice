## 定时提醒休息与整点提醒 ###
1. 功能介绍：（1）实现每45分钟提醒休息（2）休息5分钟后提醒休息结束，重新计时（3）整点时进行报时
2. 运行环境：Linux系统
3. 运行方法：终端bash命令直接运行
4. 代码组成：<br>
 &ensp;&ensp;&ensp;&ensp;&ensp;获取系统时间date<br>
 &ensp;&ensp;&ensp;&ensp;&ensp;主体循环while<br>
 &ensp;&ensp;&ensp;&ensp;&ensp;计算状态持续时间tmp<br>
 &ensp;&ensp;&ensp;&ensp;&ensp;整点报时<br>

 
